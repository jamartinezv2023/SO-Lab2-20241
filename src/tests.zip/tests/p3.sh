#!/bin/bash
sleep 4
echo Linux

